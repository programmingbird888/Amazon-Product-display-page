import React, {Component} from 'react'
import '../index.css'
import logo from './images/logo.svg';
import icon_cart from './images/icon_cart.svg';
import avatar from './images/avatar.png';


export default class Navbar extends Component {
    render() {
        return (
            <>
                <div className='container'>
                    <div className='logo_menu'>
                        <img src={logo}/>
                        <ul className='ul_list'>
                            <li className='li_list'>
                                <a href='#'>Collections</a>
                            </li>
                            <li className='li_list'>
                                <a href='#'>Men</a>
                            </li>
                            <li className='li_list'>
                                <a href='#'>Women</a>
                            </li>
                            <li className='li_list'>
                                <a href='#'>About</a>
                            </li>
                            <li className='li_list'>
                                <a href='#'>Contact</a>
                            </li>
                        </ul>
                    </div>
                    <div className='cart_profile'>
                        <a href='#'><img src={icon_cart}/></a>
                        <a href='#'><img src={avatar} className='profile'/></a>
                    </div>
                </div>
            </>
        )
    }
}
