import React, {Component} from 'react'
import '../index.css'
import image_product_1_thumbnail from './images/image_product_1_thumbnail.jpg'
import image_product_2_thumbnail from './images/image_product_2_thumbnail.jpg'
import image_product_3_thumbnail from './images/image_product_3_thumbnail.jpg'
import image_product_4_thumbnail from './images/image_product_4_thumbnail.jpg'
import image_product_1 from './images/image_product_1.jpg'
import icon_cart from './images/icon_cart.svg';
import icon_plus from './images/icon_plus.svg'
import icon_minus from './images/icon_minus.svg'

export default class Home extends Component {

  constructor(){
    super();
    this.state = {
      counter : 0,
      cart : " ",
    };

  }
    render() {
        return (
            <>
                <div className='home-container'>
                    <div className='col1'>
                        <img src={image_product_1}
                            id="main-img"/>
                        <div className='thumbnails'>
                            <img className='thumbnail activate blur' src={image_product_1_thumbnail}/>
                            <img className='thumbnail' src={image_product_2_thumbnail}/>
                            <img className='thumbnail' src={image_product_3_thumbnail}/>
                            <img className='thumbnail' src={image_product_4_thumbnail}/>
                        </div>
                    </div>
                    <div className='col2'>
                        <p id='company'>SNEAKER COMPANY</p>
                        <h1>Fall Limited Edition Sneakers</h1>
                        <p id='sneaker-info'>These low-profile sneakers are your perfect casual wear companion. Featuring a durable rubber outer sole, they'll withstand everything the weather can offer.</p>
                        <h2>$125.00<span id='discount'>50%</span>
                        </h2>
                        <span id='original-price'>$250.00</span>
                        <div className='buttons'>
                            <div className='cart-count'>
                                <button onClick={()=>this.setState({counter:this.state.counter+1})} id='count'><img src={icon_plus} /></button>
                                <p>{this.state.counter}</p>
                                <button onClick={()=>this.setState({counter:this.state.counter-1})} id='count'><img src={icon_minus} /></button>
                            </div>
                            <button onClick={()=>this.setState({cart:this.state.cart = alert("Product added to Cart!")})} id='cart'><img src={icon_cart}/>Add to cart</button>
                        </div>
                    </div>
                </div>     
     
            </>
        )
    }
}
